import requests
import time
API_KEY = '50f64751bac9c30fd64d50bbeda598d9'
""" This script scrapes all the titles from given year with required number of pages and saves them in a file"""
#year = ['{:02d}'.format(x) for x in range(5,16)]
year = [17]
#page = range(1,41)
page = range(1,3)
with open('movies_2017_test.txt', 'a') as f:
	for yr in year:
		for pg in page:
			url = 'https://api.themoviedb.org/3/discover/movie?api_key={}&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page={}&vote_average.gte=5.0&year=20{}&with_runtime.gte=80'.format(API_KEY,pg,yr)
			#print (url)
			resp = requests.get(url)

			#Log the error if there is osmething wrong
			if str(resp.status_code).startswith('4'):
				with open('log_error.txt', 'a') as f:
					f.write('Year;{} Page{},'.format(yr,pg))
					continue
			resp_json = resp.json()
			for movie in resp_json['results']:
				f.write(movie['title']+'\n')

		print ('Scrapped data from year ', yr)
